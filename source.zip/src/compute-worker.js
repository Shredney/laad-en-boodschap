function overview(r){const keep=new Set([0,r.coords.length-1]),stack=[[0,r.coords.length-1]];while(stack.length){const [a,b]=stack.pop();let best=10,index=-1;for(let i=a+1;i<b;i++){const d=EV.project(r.coords[i],r.coords[a],r.coords[b]).distance;if(d>best){best=d;index=i;}}if(index>=0){keep.add(index);stack.push([a,index],[index,b]);}}const indexes=[...keep].sort((a,b)=>a-b);r.displayCoords=indexes.map(i=>r.coords[i]);r.displayDistances=indexes.map(i=>r.ds[i]);delete r.geometry;delete r.legs;return r;}
// Runs in a dedicated Worker. No DOM, location permissions or network requests.
self.onmessage=({data:{id,kind,payload:p}})=>{try{let value;
if(kind==='json')value=JSON.parse(p);
else if(kind==='valhalla')value=EV.valhallaRoutes(p);
else if(kind==='routeData')value=p.map(r=>overview(EV.routeData(r)));
else if(kind==='passing')value=p.routes.map((r,i)=>({r,i})).filter(x=>p.vias.every(point=>EV.onRoute(point,x.r).distance<=100)).sort((a,b)=>a.r.duration-b.r.duration).map(x=>x.i);
else if(kind==='viaCandidates')value=p.routes.map(r=>overview(EV.routeData(r))).filter(r=>p.vias.every(point=>EV.onRoute(point,r).distance<=110));
else if(kind==='stores')value=p.elements.filter(e=>e.tags?.shop&&EV.position(e)).map(shop=>({shop,walk:EV.nearestShop(p.point,shop).distance})).filter(s=>s.walk<=p.radius).sort((a,b)=>(b.shop.tags.shop==='supermarket')-(a.shop.tags.shop==='supermarket')||a.walk-b.walk);
else if(kind==='sample')value=EV.sample(p.route,p.from,p.to,p.step);
else if(kind==='project')value=EV.onRoute(p.point,p.route);
else if(kind==='matches'){
 const elements=EV.mergeSources(p.osm,p.supplemental),f=p.filters;
 const matches=EV.matchShops(elements,p.mode==='near'?{...f,radius:Math.max(500,f.radius)}:f),misses=[];value={matches:[],misses};
 for(const c of matches){if(p.mode==='near'){c.km=EV.distance(c.p,p.destination)/1000;if(c.walk>f.radius){if(c.km<=p.radius&&EV.confirmedPower(c,f.minimum))misses.push(c);continue;}c.primaryRadius=f.radius;c.shops=c.shops.filter(s=>s.walk<=Math.max(250,f.radius));c.nearbyStores=c.nearbyStores.filter(s=>s.walk<=Math.max(250,f.radius));if(c.km>p.radius)continue;}else{const q=EV.onRoute(c.p,p.route);if(q.km*1000<p.from-100||q.km*1000>p.to+100||q.distance>p.width)continue;Object.assign(c,{km:q.km,seconds:q.seconds,offRoute:q.distance});}c.nearbyStores=c.nearbyStores.slice(0,40);const choices=new Map();for(const m of c.shops){delete m.shopPoint;const t=m.shop.tags||{},solar=/sunrise|sunset|dawn|dusk/i.test(t.opening_hours||''),key=solar?m.shop.type+'/'+m.shop.id:[m.chain,t.opening_hours,t['addr:country'],t['addr:state']].join('|');if(!choices.has(key))choices.set(key,m);}c.shops=[...choices.values()];value.matches.push(c);}
}
else throw new Error('Unknown background task');self.postMessage({id,value});}catch(e){self.postMessage({id,error:e.message});}};
