/* UI-only localisation. Original Dutch text is retained per node so switching
 * languages never edits data, control values, addresses or routing inputs. */
(function(root){
const rows=`Laad & Boodschap|Charge & Shop
JOUW STOP ONDERWEG|YOUR STOP ON THE WAY
Bestemming|Destination
bestemming|destination
Soort zoekopdracht|Search type
jouw stop onderweg|your stop on the way
Gratis · open data|Free · open data
Instellingen & verbinding|Settings & connections
Instellingen|Settings
Laden terwijl je boodschappen doet|Charge while you shop
Een goede stop.|A better stop.
Op jouw route.|Along your route.
Vind een snellader met een supermarkt op een paar stappen afstand.|Find a fast charger with a supermarket a short walk away.
Langs mijn route|Along my route
Rond bestemming|Near destination
Vertrek en bestemming omdraaien|Swap start and destination
Vertrekpunt|Starting point
Huidige locatie (GPS)|Current location (GPS)
Ververs GPS-locatie|Refresh GPS location
optioneel, stuur je route|optional, guide your route
Bijv. Basel, Innsbruck of een adres|e.g. Basel, Innsbruck or an address
Waar wil je naartoe?|Where are you going?
Plaats, adres of latitude, longitude|Town, address or latitude, longitude
Welk deel doorzoeken?|Which part should we search?
Slim: kort helemaal, lang eerst 2 uur|Smart: whole short trip, first 2 hours of long trips
Hele route|Whole route
Eerste / komende uren|First / next hours
Laatste uren vóór bestemming|Last hours before arrival
Komende afstand|Distance ahead
Uren vóór bestemming|Hours before arrival
Uren vooruit|Hours ahead
Kilometers vooruit|Kilometres ahead
Startzoekgebied rond bestemming|Initial search radius
Bij minder dan vijf bevestigde CCS/DC-opties met bekend vermogen vergroten we het zoekgebied automatisch tot maximaal 50 km. De supermarkt-afstand blijft jouw keuze.|If fewer than five confirmed CCS/DC options are found, the search radius expands up to 50 km. Your charger-to-shop distance stays the same.
Jouw laadstop|Charging preferences
Lader ↔ supermarkt|Charger ↔ supermarket
Afstand tot het OSM-punt of de gebouwrand. Geen berekende looproute; controleer de minikaart.|Distance to the mapped shop point or building edge, not a calculated walking route. Check the mini map.
Voorkeur vanaf|Preferred power
Ondergrens|Minimum power
Minimaal CCS-aansluitingen per locatie|Minimum CCS connectors per location
Onzekere vermeldingen apart tonen (tellen niet mee)|Show incomplete listings separately (not counted towards the target)
We streven naar minstens 5 stops, liefst meer. Dit is iets anders dan het aantal aansluitingen per locatie.|We aim for at least 5 stops. This is separate from the number of connectors at a location.
Alleen supermarkten die nu open zijn|Only supermarkets open now
Uitzetten bij vooruit plannen. Onbekende openingstijden tellen niet als open.|Turn off when planning ahead. Unknown opening hours do not count as open.
Autoroute|Driving route
Voorkeur voor snelwegen (Valhalla)|Prefer motorways (Valhalla)
Standaard autoroute (Valhalla)|Standard driving route (Valhalla)
OSRM als alternatieve dienst|OSRM alternative service
Toon mijn routes|Find routes
Vind laadstops|Find chargers
Bestemming opzoeken…|Finding destination…
Overpass lijn met|Overpass line with
hoekpunten|vertices
Zoek rond bestemming|Find nearby chargers
Zoek stops op deze route|Find chargers on this route
Supermarkt dichtbij|Supermarket nearby
Geen account, abonnement of live prijzen. Alleen de gekozen route wordt doorzocht. Routeaanbieders geven soms maar één alternatief.|Free to use. We search your selected route; the provider may offer only one alternative.
Kaart en resultaten|Map and results
Kaart met routealternatieven en laadstops|Map of route alternatives and chargers
Route via kaartpunt toevoegen|Add route via map point
Kaartpunt wissen|Clear map point
Doorzocht|Searched
Nog te onderzoeken|Not searched yet
Aanvullend / onzeker|Incomplete data
Kies je bestemming. De route blijft in beeld.|Choose a destination. Your route stays on the map.
Dicht bij de supermarkt|CHARGE. SHOP. CONTINUE.
Jouw laadstops|Charging stops
Sorteer resultaten|Sort results
Kortste reistijd|Shortest driving time
Langs de route|Along the route
Laadvoorkeur eerst|Preferred charging power first
Minste omrijden|Smallest detour
Dichtst bij winkel|Closest to shop
Streefminimum bekende CCS/DC-opties|Target number of known CCS/DC options
Zoek meer, behoud resultaten|Find more, keep results
Een hoger doel laat de app verder zoeken binnen de zoekgrenzen. Bestaande resultaten blijven staan; het doel is geen garantie.|A higher target searches further within the limits. Existing results stay visible; the target is not a guarantee.
Bezig…|Working…
Reistijd vanaf bestemming · zonder live verkeer|Driving from your destination · no live traffic
Dienst reageert niet op tijd. Probeer later of een ander eindpunt.|The service timed out. Try later or use another endpoint.
Begin met een bestemming en kies daarna je route.|Enter a destination to get started.
Stop zoeken|Stop search
Eerder op de route zoeken|Search earlier along the route
Zoek laatste 2 uur vóór bestemming|Search the last 2 hours before arrival
Verder zoeken|Search further
Doorzoek hele route|Search the whole route
Opnieuw vanaf GPS|Start again from GPS
Bij keten-/openfilter ook andere supermarkten tot minimaal 250 m toestaan|Allow alternative supermarkets up to at least 250 m when filtering chains or opening hours
De gewone afstand blijft je sliderwaarde. Een verder gelegen vervangende supermarkt krijgt de werkelijke afstand en een extra melding.|The normal distance stays at your slider value. A more distant alternative shows its actual distance and a notice.
Filter gevonden supermarktketens|Filter supermarket chains
Ketenkeuze|Chain filter
Alle ketens|All chains
Blacklisten: geselecteerde ketens uitsluiten|Exclude selected chains
Whitelisten: alleen geselecteerde ketens|Only selected chains
Aantal gevonden laadvermeldingen per keten, inclusief onzekere aanvullingen. Een andere passende supermarkt bij dezelfde lader houdt de locatie zichtbaar.|Number of charger listings per chain, including incomplete data. A location stays visible if another eligible supermarket remains.
Wis ketenfilter|Clear chain filter
Maak van laden een handige pauze.|Make charging a useful break.
Alle supermarktketens. Jouw gekozen route.|Your route. A useful place to stop.
De werkelijke omweg duidelijk in beeld.|Compare the actual driving detour.
Kies waar je naartoe gaat en bekijk de routes.|Choose where you are going and compare routes.
Vind stops in de volgorde waarin je ze tegenkomt.|Find stops in the order you reach them.
Controleer de minikaart en kopieer het adres.|Check the mini map and navigate to the charger.
© OpenStreetMap-bijdragers · ODbL|© OpenStreetMap contributors · ODbL
Bron:|Source:
Aanvulling:|Additional data:
Locaties en openingstijden kunnen onvolledig zijn. GPS/coördinaten worden voor je zoekopdracht met kaart-, adres- en routediensten gedeeld; geen achtergrondtracking.|Location and opening-hour data may be incomplete. Your search coordinates are shared with map, address and routing services. No background tracking.
Sluiten|Close
Taal / Language|Language / Taal
Geavanceerde modus|Advanced mode
Weergave bijgewerkt. Zoek opnieuw om een ander gebied te onderzoeken.|View updated. Search again to explore a different area.
Standaardinstellingen houden de app eenvoudig. Geavanceerde modus toont alle filters en technische opties.|Standard settings keep things simple. Advanced mode shows all filters and technical options.
Vervangbare publieke diensten. Eén URL per regel; routingdiensten moeten de OSRM-API ondersteunen. Gebruik voor via een plaats/adres, geen landnaam.|Replaceable public services. One URL per line; routing services must support OSRM. Use a town or address for via points, not a country.
Valhalla-route-URL|Valhalla routing URL
Overpass-eindpunten|Overpass endpoints
OSRM-basis-URL's|OSRM base URLs
Nominatim zoek-URL|Nominatim search URL
Kaarttegels (XYZ-URL)|Map tiles (XYZ URL)
Naamsvermelding kaarttegels (platte tekst)|Map tile attribution (plain text)
Bewaren|Save
Test verbindingen|Test connections
Uitgebreide routetest|Extended routing test
Kopieer testuitslag|Copy test results
Wis cache|Clear cache
Nog geen test uitgevoerd.|No test has been run yet.
Adreszoeken gebeurt alleen na verzenden, zonder autocomplete. Verzoeken gaan één voor één; resultaten worden lokaal gecachet. Geen garantie op bereikbaarheid of vijf geschikte stops.|Address searches run after submission, without autocomplete. Requests are paced and cached locally. Service availability and five suitable stops cannot be guaranteed.
Kies de juiste plaats|Choose the correct place
Annuleren|Cancel
Snelle navigatie|Quick navigation
Zoeken|Search
Kaart|Map
Resultaten|Stops
Navigatie openen|Open navigation
Naar laadpaal navigeren|Navigate to charger
Naar winkel lopen|Walk to shop
Naar laadpaal|Navigate to charger
Looproute naar de supermarkt.|Walking directions to the supermarket.
Autoroute naar de laadpaal.|Driving directions to the charger.
Je telefoon bepaalt welke geïnstalleerde app opent. Waze ondersteunt autoritten; Google Maps kan ook lopen.|Your phone decides which installed app opens. Waze supports driving; Google Maps also supports walking.
Google Maps · lopen|Google Maps · walking
Google Maps · auto|Google Maps · driving
Waze · auto|Waze · driving
Andere kaartapp|Other map app
Zoekopdracht starten…|Starting search…
seconden verstreken · resultaten komen stapsgewijs binnen|seconds elapsed · results appear as they are found
Zoeken gestopt|Search stopped
Gestopt. Reeds gevonden resultaten blijven zichtbaar; nog niet doorzochte delen zijn herkenbaar op de kaart.|Stopped. Results already found remain visible. Unsearched parts remain marked on the map.
Dienst antwoordt HTTP|Service returned HTTP
Dienst reageert niet binnen 70 seconden. Probeer later of een ander eindpunt.|The service timed out. Try later or use another endpoint.
Publieke dienst is druk. We wachten 30 seconden vóór een nieuw verzoek.|The public service is busy. Waiting 30 seconds before the next request.
Controleer je internetverbinding of test de eindpunten bij Instellingen.|Check your connection or test the services in Settings.
Valhalla gaf geen autoroute. Kies eventueel OSRM als andere dienst.|Valhalla returned no driving route. Try OSRM as an alternative.
Adres opzoeken:|Looking up address:
Geen adres gevonden voor|No address found for
Probeer straat, plaats en land.|Try a street, town and country.
Je browser vraagt toestemming voor je locatie…|Your browser will ask for location permission…
GPS niet beschikbaar. Vul een vertrekadres in.|GPS is unavailable. Enter a starting address.
GPS niet beschikbaar of geweigerd. Gebruik HTTPS en geef locatietoestemming, of vul een vertrekadres in.|GPS is unavailable or permission was denied. Allow location access on HTTPS, or enter a starting address.
Ongeldige coördinaten|Invalid coordinates
Kies je bestemming.|Choose your destination.
Kies een bestemming en daarna de route.|Choose a destination, then choose your route.
Zoek zonder vertrekpunt in een instelbare cirkel rond je bestemming.|Find chargers near a destination, without a starting point.
gekozen. Start nu het zoeken naar stops.|selected. Now search for chargers.
gekozen. Zoek opnieuw op deze route.|selected. Search again along this route.
locaties passen bij je keten- en openingstijdenfilters. Afstanden zijn opnieuw aan de gekozen supermarkt gekoppeld.|locations match your chain and opening-hour filters. Distances now refer to the selected supermarket.
Verberg aanvullende locaties op kaart|Hide incomplete listings on map
Toon aanvullende locaties op kaart|Show incomplete listings on map
Aanvullend: laadgegevens of omweg onzeker|Additional listing: charging data or detour uncertain
Tik op de gewenste routecorridor…|Tap near the road you want…
Tik ongeveer op de gewenste weg. De router kiest een doorgaande rijrichting binnen circa 100 m; je hoeft de juiste rijstrook niet precies te raken.|Tap near the road you want. Routing considers through roads within about 100 m; you do not need to hit the correct lane.
Kaartpunt kiezen geannuleerd.|Map-point selection cancelled.
Route zonder extra kaartpunten gekozen. Zoek de laadstops opnieuw op deze route.|Selected a route without extra map points. Search for chargers again.
passeert al binnen circa 100 m van de gekozen punten en is geselecteerd, zonder extra omweg naar een rijstrook of parallelweg.|already passes within about 100 m of your points and has been selected without an extra detour to a specific lane or side road.
Nieuwe autoroute via de gekozen corridor berekenen…|Calculating a new driving route via your point…
Geen doorgaande autoroute binnen circa 100 m van dit punt gevonden. Tik iets dichter bij de gewenste weg.|No through driving route was found within about 100 m. Tap closer to the desired road.
route(s) toegevoegd via deze corridor. Kies de gewenste lijn of routeknop en zoek opnieuw de laadstops.|route(s) added via this area. Choose a route and search for chargers again.
omweg volgt|detour pending
km vanaf start|km from start
aankomst onbekend|arrival unknown
Nederlandse vergelijking:|Dutch comparison:
(globaal winkelformaat)|(approximate shop format)
Exploitant onbekend|Operator unknown
laadtype onbekend|charging type unknown
aansluitingen|connectors
m tot winkel|m to shop
Nabij alternatief:|Nearby alternative:
; buiten de gewone|; outside the normal
m, toegestaan door de optie voor alternatieven.|m, allowed by the alternative-shop setting.
Verruimde omweg · boven de eerste grens van 5 km|Expanded detour · beyond the initial 5 km limit
Omweg niet berekend; niet meegeteld bij het zoekdoel|Detour unavailable; not counted towards the target
Details & minikaart|Details & mini map
Laadpunt en supermarkt|Charger and supermarket
Groen laadpaalsymbool = lader · blauw P = gekozen supermarkt · paars S = andere supermarkt · goud B = eten/handige winkel · grijs = overige winkel.|Green charger = charging point · blue P = selected supermarket · purple S = other supermarket · gold B = food/useful shop · grey = other shop.
m tot OSM-punt/gebouwrand; geen gegarandeerde loopverbinding. Controleer wegen, hekken en parkeerterreinen.|m to the mapped point/building edge; no guaranteed walking connection. Check roads, gates and car parks.
Laadlocatie|Charging location
Naam onbekend|Name unknown
Exploitant|Operator
CCS-vermogen|CCS power
CCS; totale capaciteit:|CCS; total capacity:
Connectoren (OSM)|Connectors (OSM)
Winkel open|Shop opening hours
Lader open / toegang|Charger opening hours / access
Coördinaten laadpaal|Charger coordinates
Adres lader|Charger address
Adres winkel|Shop address
Kopieer laadpaalcoördinaten|Copy charger coordinates
Kopieer laadadres|Copy charger address
Kopieer winkeladres|Copy shop address
Kopieer winkelcoördinaten|Copy shop coordinates
Google Maps: laadpaalpin|Google Maps: charger pin
OSM-brongegevens|OSM source data
Zonder vertrekroute zijn aankomsttijd en omrijafstand niet van toepassing.|Without a journey route, arrival time and detour distance do not apply.
Supermarkten en andere winkels in de buurt|Supermarkets and other nearby shops
Aanvullende winkels worden bij openen opgehaald.|Additional shops load when you open these details.
Gekozen supermarkt|Selected supermarket
Andere supermarkt|Other supermarket
Eten en handige winkels|Food and useful shops
Overige winkels|Other shops
uitgesloten door ketenfilter|excluded by chain filter
buiten toegestane afstand|outside the allowed distance
nabij alternatief|nearby alternative
nu gesloten|closed now
nu open|open now
opening onbekend|opening hours unknown
Toon op minikaart|Show on mini map
Actuele bezetting niet beschikbaar op deze host|Live availability is not supported on this host
Haal actuele bezetting op|Check live availability
Optioneel, NDW Nederland. Geen live beschikbaarheid afgeleid uit een oude momentopname.|Optional NDW data for the Netherlands. Snapshot data is never presented as live availability.
Actuele brongegevens ophalen…|Checking current source data…
Actuele bezetting onbekend:|Live availability unknown:
Laadgegevens:|Charging data:
bijgewerkt|updated
NDW-koppeling op|NDW match at
aangevuld:|added:
bestaande OSM-waarden behouden|existing OSM values retained
NDW-brongegevens|NDW source data
Bereken omweg voor deze locatie|Calculate this detour
Omweg voor deze locatie berekenen…|Calculating this detour…
Omweg berekend.|Detour calculated.
Bekijk op hoofdkaart|Show on main map
Openingstijden onbekend|Opening hours unknown
Andere winkels in de buurt ophalen…|Loading other nearby shops…
Winkels binnen|Shops within
m van de lader; de geselecteerde supermarkt is blauw (P), andere supermarkten paars (S), eten/handige winkels goud (B) en overige winkels grijs. Alleen toegestane supermarkten bepalen het resultaat.|m of the charger: selected supermarket blue (P), other supermarkets purple (S), food/useful shops gold (B), other shops grey. Only eligible supermarkets determine whether a charger is included.
Andere winkels tijdelijk niet bereikbaar. De gevonden supermarkten blijven zichtbaar; klap opnieuw open om te proberen.|Other shops are temporarily unavailable. Supermarkets already found stay visible. Reopen to retry.
bevestigde laadstops|confirmed charging stops
bevestigde laadstop|confirmed charging stop
Bereken volgende|Calculate next
omwegen|detours
Aanvullende omweg|Additional detour
Aanvullende omwegen bijgewerkt.|Additional detours updated.
Nog geen geschikte CCS/DC-opties met bekend vermogen gevonden. Onbekende vermeldingen tellen niet mee voor het minimum van vijf.|No suitable CCS/DC options with known power found yet. Incomplete listings do not count towards the target of five.
bekende CCS/DC-locaties vallen buiten jouw supermarkt-afstand van|known CCS/DC locations are outside your charger-to-supermarket distance of
m. Dichtst bij je bestemming:|m. Nearest to your destination:
m tot het OSM-winkelpunt/gebouw. Dit is geen berekende loopafstand.|m to the mapped shop point/building. This is not a calculated walking distance.
Vergroot tot|Increase to
m en zoek opnieuw|m and search again
Aanvullend:|Additional:
onzekere vermeldingen (tellen niet mee)|incomplete listings (not counted towards the target)
Gekopieerd|Copied
Kopieer deze tekst:|Copy this text:
Geen route via laadpunt|No route via charger
Deze host ondersteunt geen NDW-serverfunctie; actuele bezetting blijft onbekend.|This host has no NDW server function; live availability remains unknown.
Onbekend: deze aanvullende livebron dekt Nederland.|Unknown: this additional live source covers the Netherlands.
bron niet bereikbaar (HTTP|source unavailable (HTTP
); lokaal eventueel start.cmd opnieuw starten|); restart start.cmd if using the local app
Onbekend: geen betrouwbare koppeling met CCS/DC-status in de aanvullende bron.|Unknown: no reliable match with CCS/DC status in the additional source.
vrij aantal onbekend|available count unknown
vrij /|available /
Storing: niet apart beschikbaar in deze bron; 0 vrij kan bezet, buiten gebruik of onbekend betekenen. Opgehaald|Fault status is not provided separately; 0 available may mean occupied, unavailable or unknown. Checked
laatste bronwijziging|last source update
Aanvullende laadpuntbron: NDW/DOT-NL (Nederland),|Additional charger source: NDW/DOT-NL (Netherlands),
geen datum|date unknown
Deze statische host gebruikt de gebundelde momentopname; vernieuwen en actuele bezetting vragen een NDW-serverfunctie.|This static host uses a bundled snapshot. Refreshing NDW data and live availability require a server function.
Momentopname: rechtstreeks openen ondersteunt geen bronverversing.|Snapshot: opening a local file does not support source refresh.
Lokale dagcache; geen nieuwe download nodig.|Daily local cache; no new download needed.
Wordt op de achtergrond ververst; de aanwezige momentopname is al bruikbaar.|Refreshing in the background; the existing snapshot is already usable.
Bron vernieuwd; ontbrekende CCS-gegevens worden alleen bij een passende locatie gekoppeld.|Source refreshed; missing CCS data is added only to a reliably matched location.
Momentopname in gebruik. NDW-verversing is niet bereikbaar; bestaande gegevens blijven werken. Lokaal: herstart start.cmd na een update.|Using snapshot data. NDW refresh is unavailable; existing data still works. Restart start.cmd after an app update if running locally.
Zoeken binnen|Searching within
km rond bestemming|km of destination
(automatisch verruimd vanaf|(automatically expanded from
van minimaal|of target
bevestigde CCS/DC-opties met bekend vermogen.|confirmed CCS/DC options with known power.
Rond bestemming ·|Near destination ·
automatisch verruimd|automatically expanded
Doorzocht: cirkel van|Searched: radius
Startgebied:|Initial radius:
km. Lader ↔ supermarkt blijft maximaal|km. Charger ↔ supermarket remains within
m. Omweg niet van toepassing.|m. Journey detour does not apply.
bevestigde CCS/DC-opties met bekend vermogen gevonden binnen|confirmed CCS/DC options with known power found within
Zoekdoel van minstens|Target of at least
Zoekdoel van|Target of
niet gehaald binnen 50 km met de huidige filters en beschikbare OSM-gegevens. Er worden geen laadtypen of vermogens verzonnen.|not reached within 50 km with the current filters and available data. Charging types and power are never invented.
gehaald; alle gevonden bevestigde opties blijven zichtbaar.|reached; all confirmed options found remain visible.
onzekere vermeldingen staan apart ingeklapt en tellen niet mee.|incomplete listings are shown separately and do not count towards the target.
Geen loopgarantie.|Walking access is not guaranteed.
Kies eerst een route.|Choose a route first.
Locaties ophalen langs|Finding locations along
bevestigde omwegen gereed|confirmed detours ready
Omweg voor bevestigde CCS/DC-lader|Detour for confirmed CCS/DC charger
van maximaal|of up to
in deze eerste ronde · overige opties zijn al zichtbaar|in this first round · other options are already visible
Actief venster:|Active section:
tot bestemming|to destination
omweggrens|detour limit
(verruimd)|(expanded)
CCS/DC-opties met berekende omweg in het actieve routevenster.|CCS/DC options with calculated detours in the active section.
Minder dan|Fewer than
opties met bevestigde omweg binnen de onderzochte grenzen.|options with confirmed detours within the search limits.
aanvullende omwegen zijn nog niet berekend; gebruik de knop bij de resultaten of een locatie.|additional detours are pending; use the results button or a specific location.
Laadtype/vermogen en omwegstatus staan afzonderlijk aangegeven. Zonder live verkeer.|Charging data and detour status are shown separately. No live traffic.
Welke bestemming bedoel je?|Which destination do you mean?
Welk vertrekpunt bedoel je?|Which starting point do you mean?
Welk via-punt bedoel je?|Which via point do you mean?
Routealternatieven ophalen…|Finding route alternatives…
Geen autoroute gevonden.|No driving route found.
beschikbaar. Kies op de kaart of met de routeknoppen. Zoek daarna de laadstops.|available. Choose on the map or with the route buttons, then search for chargers.
Gebruik een via-plaats als je een andere corridor wilt.|Use a via point to request another route corridor.
Vul beide plaatsen in voordat je ze omdraait; een lege GPS-locatie is geen bestemmingsadres.|Enter both places before swapping. An empty GPS field is not a destination address.
Vertrek en bestemming omgedraaid. Bereken de routes opnieuw; eenrichtingswegen kunnen de terugreis veranderen.|Start and destination swapped. Find routes again; one-way roads can change the return trip.
GPS bijgewerkt. Bij plannen gebruiken we je actuele locatie.|GPS updated. Planning will use your current location.
Instelling gewijzigd. Zoek opnieuw met de nieuwe instellingen.|Setting changed. Search again with the new settings.
locaties passen bij het ketenfilter.|locations match the chain filter.
Alternatieve supermarkten opnieuw getoetst aan de zichtbare afstandsinstellingen.|Alternative supermarkets have been checked against the visible distance settings.
Alleen supermarkten met bevestigde opening op dit moment. Onbekende tijden zijn uitgesloten; dit is geen berekening voor een toekomstige aankomst.|Only supermarkets confirmed open now. Unknown hours are excluded. This does not predict opening at a future arrival time.
Filter nu geopend uit: geschikt voor vooruit plannen.|Open-now filter off: suitable for planning ahead.
Lokaal HTML: GPS, browserrechten en CORS kunnen beperkt zijn. Geen installatie als volledige PWA. Gebruik HTTPS-hosting voor betrouwbaar mobiel gebruik.|Local HTML: GPS, browser permissions and cross-origin access may be limited. Use HTTPS hosting for reliable mobile use and app installation.
HTTPS of localhost: GPS kan met toestemming werken. Via je browsermenu kun je de app op je startscherm installeren. Internet blijft nodig voor kaarten en nieuwe zoekopdrachten.|HTTPS or localhost: GPS works with permission. Add the app to your home screen through your browser menu. Maps and new searches require internet.
Vul minimaal één eindpunt per dienst in.|Enter at least one endpoint per service.
Gebruik HTTPS-URL’s.|Use HTTPS URLs.
Instellingen bewaard. Plan de route opnieuw.|Settings saved. Find routes again.
Zoekcache gewist|Search cache cleared
Adreszoeken|Address search
object(en)|object(s)
adres(sen)|address(es)
Klaar. Een geslaagde test geldt voor dit apparaat en dit moment; geen beschikbaarheidsgarantie.|Done. A successful test applies to this device and moment; availability is not guaranteed.
Reistijden over de weg berekenen ·|Calculating road travel times ·
locaties over, inclusief onzekere laadgegevens|locations left, including incomplete charging data
Geen reistijdmatrix|No travel-time matrix
Bereken meer reistijden|Calculate more travel times
Reistijd berekenen…|Calculating travel time…
Reistijd onbekend|Travel time unavailable
Geen autoroute|No driving route
km over de weg|km by road
min rijden|min drive
hemelsbreed|straight-line
rijden|driving
Supermarkt|Supermarket
supermarkt|supermarket
Laadpunt|Charger
Voorkeur|Preferred
Tweede keus|Alternative
Onzekere laadgegevens|Incomplete charging data
Onzekere vermeldingen tellen niet mee voor het zoekdoel|Incomplete listings do not count towards the target
Minder dan vijf bevestigde opties gevonden.|Fewer than five confirmed options were found.
onzekere vermeldingen|incomplete listings
locaties|locations
vanaf|from
binnen|within
Onbekend|Unknown
onbekend|unknown
CCS niet bevestigd|CCS not confirmed
Bevestigd CCS/DC|Confirmed CCS/DC
CCS-vermogen onbekend|CCS power unknown
aantal CCS-aansluitingen onbekend|CCS connector count unknown
Adres onbekend|Address unknown
omrijafstand|detour distance
omrijminuten|detour minutes
over |in 
 km om| km detour
 min om| min detour
 u | h 
bakker|bakery
drogisterij|health and beauty shop
slager|butcher
buurtwinkel|convenience store
kapper|hairdresser
een Nederlandse bakker|a Dutch bakery
Action-achtig|similar to Action
Beperkte statistieken: bezoeken en functiegebruik. Geen vertrekpunten, bestemmingen, zoekgebieden, adressen, exacte coördinaten of complete routes. Geen analyticscookies of eigen gebruikers-ID. GoatCounter ontvangt het IP-adres bij het netwerkverzoek; zie hun privacybeleid. Bezoekersaantallen zijn schattingen. Uitzetten stopt nieuwe metingen.|Basic statistics: visits and feature usage. No origins, destinations, search areas, addresses, exact coordinates or complete routes. No analytics cookies or app-generated visitor ID. GoatCounter receives the IP address with the network request; see its privacy policy. Visitor counts are estimates. Turning this off stops new measurements.
Ruw vergelijkbaar met|Roughly comparable to
Legenda en uitleg|Legend & help
Terug naar instellingen|Back to settings
Kleur én letters helpen je locaties te herkennen.|Colours and letters help you identify locations.
Laadpaal|Charger
Genummerde groene pin: bevestigd CCS/DC-vermogen. Nummer hoort bij de resultaatkaart.|Numbered green marker: confirmed CCS/DC power. The number matches the result card.
Onvolledige laadgegevens|Incomplete charging data
Oranje pin: vermogen of CCS-gegevens ontbreken. Telt niet mee voor het streefminimum.|Orange marker: power or CCS data is missing. Does not count towards the target.
Oranje bestemmingspin: jouw ingevoerde eindpunt.|Orange destination marker: the destination you entered.
Blauw: de winkel die bij deze laadstop wordt getoond.|Blue: the selected shop for this charging stop.
Paars: een supermarkt in de buurt. Je afstands- en ketenfilters bepalen of deze als alternatief past.|Purple: a nearby supermarket. Your distance and chain filters determine whether it is an eligible alternative.
Goud: bijvoorbeeld een bakker, drogist of buurtwinkel.|Gold: for example a bakery, health and beauty shop, or convenience store.
Grijs: andere winkels, ter oriëntatie.|Grey: other shops for orientation.
Afstanden en tijden|Distances and times
Rond bestemming: rijtijd en wegafstand vanaf de bestemming naar de laadpaal. Langs de route: extra tijd en kilometers voor de laadstop. Zonder live verkeer.|Near destination: driving time and road distance from your destination to the charger. Along my route: extra driving time and distance for the stop. No live traffic.
≈ Afstand tot het winkelpunt of de gebouwrand, geen berekende wandelroute. Controleer oversteekplaatsen en toegangen op de minikaart.|≈ Distance to the mapped shop point or building edge, not a calculated walking route. Check crossings and entrances on the mini map.
Voorkeur: bekend vermogen vanaf jouw voorkeurswaarde. Tweede keus: wel boven de ondergrens. Onbekend is nooit een bevestigd vermogen.|Preferred: confirmed power at or above your preferred value. Alternative: still meets your minimum power. Unknown never means confirmed power.
Groene routelijn: doorzocht. Blauwgrijs: nog niet doorzocht. Een zoekdoel is geen garantie dat zoveel geschikte locaties bestaan.|Green route line: searched. Blue-grey: not yet searched. A target does not guarantee that enough suitable locations exist.
Naar laadpaal: autoroute naar exacte laadpaalcoördinaten. Naar winkel lopen: wandelroute naar de winkel. Je telefoon bepaalt welke app opent.|Navigate to charger: driving directions to the exact charger coordinates. Walk to shop: walking directions to the shop. Your phone determines which app opens.
Gebruiksstatistieken en privacy|Usage statistics & privacy
Deel gebruiksstatistieken|Share usage statistics
Statistieken worden gecontroleerd…|Checking statistics settings…
Centrale statistieken zijn nog niet ingesteld. Er worden geen statistieken verstuurd.|Central statistics are not configured yet. No statistics are sent.
Je browser vraagt om niet te volgen. Statistieken staan uit.|Your browser requests no tracking. Statistics are off.
Lokale test: er worden geen statistieken verstuurd.|Local preview: no statistics are sent.
Statistieken delen staat aan. Je kunt dit hier altijd uitzetten.|Sharing statistics is on. You can turn it off here at any time.
Statistieken delen staat uit.|Sharing statistics is off.
Optioneel: functieklikken en grove vertrek-/bestemmingsgebieden van circa 60–110 km. Geen namen, adressen, exacte coördinaten of complete routes. GoatCounter ontvangt het IP-adres bij het netwerkverzoek; zie hun privacybeleid. Bezoekersaantallen zijn schattingen. Uitzetten stopt nieuwe metingen.|Optional: feature clicks and broad origin/destination regions covering tens of kilometres. No names, addresses, exact coordinates or complete routes. GoatCounter receives the IP address with the network request; see its privacy policy. Visitor counts are estimates. Turning this off stops new measurements.
GoatCounter privacybeleid ↗|GoatCounter privacy policy ↗
Optionele statistieken|Optional statistics
Help de app verbeteren?|Help improve the app?
Deel functiegebruik en grove zoekgebieden. Geen exacte adressen of coördinaten. Je kunt dit wijzigen bij Instellingen.|Share feature usage and broad search regions. No exact addresses or coordinates. You can change this in Settings.
Statistieken toestaan|Allow statistics
Nee, bedankt|No thanks
`;
const extra=[['Omweg: berekende autoroute van een vertrekpunt op jouw route via de lader naar een terugkeerpunt op dezelfde route, vergeleken met dat routegedeelte. Zonder live verkeer. Aankomst via dit vertrekpunt; geen batterijberekening.','Detour: a calculated driving route from your route via the charger and back to your route, compared with that route section. No live traffic or battery planning.'],['Start de app via start.cmd in de appmap. Open daarna http://127.0.0.1:8765/. OpenStreetMap-kaarten kunnen vanuit een lokaal HTML-bestand worden geblokkeerd. Voor je telefoon: gebruik HTTPS-hosting.','Run start.cmd and open http://127.0.0.1:8765/. Map tiles can be blocked when opening a local HTML file directly. Use HTTPS hosting on your phone.'],['Start eerst start.cmd in de appmap en gebruik http://127.0.0.1:8765/. Rechtstreeks openen via file:// werkt niet met de standaard kaartdienst.','Run start.cmd first and use http://127.0.0.1:8765/. The standard map service does not work through file://.'],['of target','of target'],['Geen routevia','No route via']];
const dictionary=new Map(rows.split('\n').map(row=>{const i=row.indexOf('|');return [row.slice(0,i),row.slice(i+1)];}).filter(x=>x[0]).concat(extra));
const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const pattern=new RegExp([...dictionary.keys()].sort((a,b)=>b.length-a.length).map(key=>(/^\p{L}/u.test(key)?'(?<![\\p{L}])':'')+escape(key)+(/\p{L}$/u.test(key)?'(?![\\p{L}])':'')).join('|'),'gu');
function translate(text,language='en'){return language==='nl'?text:String(text).replace(pattern,match=>dictionary.get(match));}
root.I18N={translate};if(typeof module!=='undefined')module.exports=root.I18N;
if(typeof document==='undefined')return;
let language='en';const original=new WeakMap(),attributes=new WeakMap();
function excluded(node){return !!node.parentElement?.closest('script,style,[data-no-i18n],input,textarea');}
function apply(rootNode){if(rootNode.nodeType===3){if(excluded(rootNode))return;const current=rootNode.nodeValue;let item=original.get(rootNode);if(!item||current!==item.last)item={source:current,last:current};const next=translate(item.source,language);if(current!==next)rootNode.nodeValue=next;item.last=next;original.set(rootNode,item);return;}if(rootNode.nodeType!==1&&rootNode.nodeType!==9&&rootNode.nodeType!==11)return;const walker=document.createTreeWalker(rootNode,NodeFilter.SHOW_TEXT);while(walker.nextNode())apply(walker.currentNode);const elements=rootNode.nodeType===1?[rootNode,...rootNode.querySelectorAll('[placeholder],[title],[aria-label]')]:[...rootNode.querySelectorAll('[placeholder],[title],[aria-label]')];for(const el of elements){if(el.closest('[data-no-i18n]'))continue;let record=attributes.get(el)||{};for(const attr of ['placeholder','title','aria-label']){if(!el.hasAttribute(attr))continue;const current=el.getAttribute(attr),entry=record[attr];const source=entry&&current===entry.last?entry.source:current,next=translate(source,language);if(current!==next)el.setAttribute(attr,next);record[attr]={source,last:next};}attributes.set(el,record);}}
const observer=new MutationObserver(changes=>{for(const change of changes){if(change.type==='characterData')apply(change.target);else if(change.type==='childList')for(const node of change.addedNodes)apply(node);else apply(change.target);}});
observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['placeholder','title','aria-label']});
root.I18N.setLanguage=value=>{language=value==='nl'?'nl':'en';document.documentElement.lang=language;apply(document);};
})(typeof globalThis!=='undefined'?globalThis:this);
