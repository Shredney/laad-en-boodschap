(function(root){
'use strict';
// Explicit event names only: never DOM text, addresses, input values or full URLs.
const features=new Set(['visit','search-route','search-near','route-selected','reverse-route','gps','via-map','search-next','search-last','search-previous','search-whole','more-results','cancel-search','details-open','show-incomplete-map','navigate-charger','navigate-shop','navigation-google','navigation-waze','navigation-other','copy-charger-coordinates','copy-address','chain-filter','open-now','filter-change','advanced-on','advanced-off','language-en','language-nl','legend-open','dock-search','dock-map','dock-results','calculate-times','calculate-detours']);
function validCode(code){return typeof code==='string'&&/^[a-z0-9][a-z0-9-]{0,60}[a-z0-9]$/.test(code);}
function create({code='',consent=()=>false,blocked=()=>false,send=()=>{},enabled=()=>true}={}){let sent=0;return {event(name){if(!features.has(name))return false;if(!validCode(code)||!consent()||blocked()||!enabled()||sent>=200)return false;sent++;try{send('https://'+code+'.goatcounter.com/count?'+new URLSearchParams({p:name==='visit'?'/app':name,t:name==='visit'?'Charge & Shop':name,e:name==='visit'?'false':'true',rnd:String(Math.random())}));return true;}catch{return false;}}};}
const api={validCode,create};root.EVStats=api;if(typeof module!=='undefined')module.exports=api;
if(typeof document==='undefined')return;
const $=id=>document.getElementById(id);let code='',choice='yes',loaded=false;
try{choice=localStorage.getItem('ev-stats-disabled-v1')==='yes'||localStorage.getItem('ev-stats-consent-v1')==='no'?'no':'yes';}catch{}
const blocked=()=>navigator.doNotTrack==='1'||navigator.doNotTrack==='yes'||navigator.globalPrivacyControl===true;
// No analytics from localhost/file previews. No cookies, identifier, retry queue or local search history.
const enabled=()=>location.protocol==='https:'&&!['localhost','127.0.0.1','::1'].includes(location.hostname);
const images=new Set();
function send(url){const img=new Image();img.referrerPolicy='no-referrer';images.add(img);const finish=()=>images.delete(img);img.onload=finish;img.onerror=finish;img.src=url;setTimeout(finish,15000);}
function makeTracker(){return create({code,consent:()=>choice==='yes',blocked,enabled,send});}
let activeTracker=makeTracker();
function update(){const available=validCode(code);$('statsConsent').checked=choice==='yes'&&!blocked();$('statsConsent').disabled=!available||blocked();$('statsStatus').textContent=!loaded?'Statistieken worden gecontroleerd…':!available?'Centrale statistieken zijn nog niet ingesteld. Er worden geen statistieken verstuurd.':blocked()?'Je browser vraagt om niet te volgen. Statistieken staan uit.':!enabled()?'Lokale test: er worden geen statistieken verstuurd.':choice==='yes'?'Statistieken delen staat aan. Je kunt dit hier altijd uitzetten.':'Statistieken delen staat uit.';}
function setChoice(value){choice=value;try{localStorage.setItem('ev-stats-disabled-v1',choice==='yes'?'no':'yes');localStorage.removeItem('ev-stats-consent-v1');}catch{}update();if(choice==='yes')activeTracker.event('visit');}
$('statsConsent').onchange=()=>setChoice($('statsConsent').checked?'yes':'no');
root.EVStats.event=name=>activeTracker.event(name);root.EVStats.recordSearch=mode=>activeTracker.event(mode==='near'?'search-near':'search-route');
// This file is public configuration, containing only a public site code, never an API key.
fetch('./analytics-config.json',{cache:'no-store'}).then(r=>r.ok?r.json():{}).then(data=>{code=validCode(data.siteCode)?data.siteCode:'';trackerCodeInit();}).catch(()=>trackerCodeInit());
function trackerCodeInit(){loaded=true;activeTracker=makeTracker();update();if(choice==='yes')activeTracker.event('visit');}
// Use a fixed allowlist instead of a catch-all click logger.
const clickIds={reverseRoute:'reverse-route',gps:'gps',nearGps:'gps',nearMore:'more-results',addVia:'via-map',next:'search-next',searchLast:'search-last',searchFirst:'search-route',searchCurrent:'gps',previous:'search-previous',whole:'search-whole',moreResults:'more-results',cancel:'cancel-search',legendBtn:'legend-open'};
document.addEventListener('click',e=>{const button=e.target.closest('button,a');if(!button)return;let name=clickIds[button.id]||button.dataset.stat;if(button.matches('.nav-charger'))name='navigate-charger';else if(button.matches('.nav-shop'))name='navigate-shop';else if(button.matches('.copy-charger-coordinates'))name='copy-charger-coordinates';else if(button.matches('.copy-charger,.copy-shop'))name='copy-address';else if(button.closest('#routeOptions'))name='route-selected';else if(button.closest('.mobile-dock'))name='dock-'+button.dataset.section;else if(button.closest('#navApps')){const href=button.getAttribute('href')||'';name=href.startsWith('geo:')?'navigation-other':href.includes('waze.com')?'navigation-waze':'navigation-google';}if(name)root.EVStats.event(name);});
document.addEventListener('change',e=>{const id=e.target.id;let name;if(id==='advancedMode')name=e.target.checked?'advanced-on':'advanced-off';else if(id==='languageSelect')name='language-'+e.target.value;else if(id==='additionalMapToggle')name='show-incomplete-map';else if(id==='chainMode'||e.target.closest('#chainList'))name='chain-filter';else if(id==='openNow')name='open-now';else if(['radius','preferred','minimum','points','target','area','scope','hours','kilometers','routePreference','nearbyAlternatives','unknown','sort'].includes(id))name='filter-change';if(name)root.EVStats.event(name);});
document.addEventListener('toggle',e=>{if(e.target.matches?.('details.stop')&&e.target.open)root.EVStats.event('details-open');},true);
$('legendBtn').onclick=()=>{$('settings').close();$('legendDialog').showModal();};$('closeLegend').onclick=()=>{$('legendDialog').close();$('settings').showModal();};
update();
})(typeof globalThis!=='undefined'?globalThis:this);
